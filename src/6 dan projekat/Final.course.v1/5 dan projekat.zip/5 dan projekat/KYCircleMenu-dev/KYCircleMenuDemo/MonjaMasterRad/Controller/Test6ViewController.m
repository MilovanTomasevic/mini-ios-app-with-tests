//
//  Test6ViewController.m
//  KYCircleMenuDemo
//
//  Created by Milovan Tomasevic on 22/07/2018.
//  Copyright © 2018 Kjuly. All rights reserved.
//

#import "Test6ViewController.h"

@interface Test6ViewController ()

@end

@implementation Test6ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //[self.rightButton performSelector:@selector(AboutButtonPressedWith:) withObject:nil];
}



@end
