//
//  Semafor.m
//  KYCircleMenuDemo
//
//  Created by Monja Tadic on 22/07/2018.
//  Copyright © 2018 Kjuly. All rights reserved.
//

#import "Semafor.h"

@implementation Semafor

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.stanjeSemafora = sON;
    }
    return self;
}
@end
