package utils;

/**
 * Created by mt on 25/07/2018.
 */
public interface Constants {

    final String SERVER_URL = "http://0.0.0.0:4723/wd/hub";

}
