package tests;

import io.appium.java_client.ios.IOSDriver;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import utils.Config;
import utils.Constants;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * Created by mt on 25/07/2018.
 */
public class Semafor {

    IOSDriver driver;

    @Before
    public void setup() throws MalformedURLException {
        driver = new IOSDriver<>(new URL(Constants.SERVER_URL), Config.iOS.getCapabilities()); // Breaks here when i debugged
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @After
    public void teardown() {
        driver.quit();
    }

    @Test
    public  void stanjeSemafora() throws InterruptedException {

        driver.findElement(By.id("KYICircleMenuCenterButton")).click();
        driver.findElement(By.id("KYICircleMenuButton01")).click();

        Thread.sleep(1000);

        driver.findElement(By.id("▶️")).click();
        System.out.println("Stanje semafora: " + driver.findElement(By.id("Semafor radi.")).getText());

        String text = driver.findElement(By.id("Semafor radi.")).getText();

        if(text.equals("Semafor radi.")) {
            System.out.println("Provera RADI - OK");
        }

        driver.findElement(By.id("⤵️")).click();
        System.out.println("Stanje semafora: " + driver.findElement(By.id("Semafor pokvaren.")).getText());

        String text2 = driver.findElement(By.id("Semafor pokvaren.")).getText();

        if(text2.equals("Semafor pokvaren.")) {
            System.out.println("Provera POKVAREN - OK");
        }

        driver.findElement(By.id("⤴️")).click();
        System.out.println("Stanje semafora: " + driver.findElement(By.id("Semafor popravljen.")).getText());

        String text3 = driver.findElement(By.id("Semafor popravljen.")).getText();

        if(text3.equals("Semafor popravljen.")) {
            System.out.println("Provera POPRAVLJEN - OK");
        }

    }

    @Test
    public  void fixSemafor() throws InterruptedException {

        driver.findElement(By.id("KYICircleMenuCenterButton")).click();
        driver.findElement(By.id("KYICircleMenuButton01")).click();

        Thread.sleep(1000);

        driver.findElement(By.id("▶️")).click();
        System.out.println("Stanje semafora: " + driver.findElement(By.id("Semafor radi.")).getText());

        String text = driver.findElement(By.id("Semafor radi.")).getText();

        if(text.equals("Semafor radi.")) {
            System.out.println("Provera RADI - OK");
        }

        driver.findElement(By.id("⤵️")).click();
        System.out.println("Stanje semafora: " + driver.findElement(By.id("Semafor pokvaren.")).getText());

        String text2 = driver.findElement(By.id("Semafor pokvaren.")).getText();

        if(text2.equals("Semafor pokvaren.")) {
            System.out.println("Provera POKVAREN - OK");
        }

        driver.findElement(By.id("⤴️")).click();
        System.out.println("Stanje semafora: " + driver.findElement(By.id("Semafor popravljen.")).getText());

        String text3 = driver.findElement(By.id("Semafor popravljen.")).getText();

        if(text3.equals("Semafor popravljen.")) {
            System.out.println("Provera POPRAVLJEN - OK");
        }

    }
}

